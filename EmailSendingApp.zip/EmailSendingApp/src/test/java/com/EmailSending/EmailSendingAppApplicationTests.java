package com.EmailSending;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmailSendingAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
